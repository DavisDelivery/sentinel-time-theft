
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_firebase-admin.js
import crypto from "crypto";
var _accessToken = null;
var _tokenExpiry = 0;
function getProjectId() {
  return Netlify.env.get("FIREBASE_PROJECT_ID");
}
async function getAccessToken() {
  if (_accessToken && Date.now() < _tokenExpiry - 6e4) return _accessToken;
  const clientEmail = Netlify.env.get("FIREBASE_CLIENT_EMAIL");
  let privateKey = Netlify.env.get("FIREBASE_PRIVATE_KEY");
  if (!clientEmail || !privateKey) throw new Error("Firebase credentials not set");
  privateKey = privateKey.replace(/\\n/g, "\n");
  const now = Math.floor(Date.now() / 1e3);
  const header = { alg: "RS256", typ: "JWT" };
  const claim = {
    iss: clientEmail,
    scope: "https://www.googleapis.com/auth/datastore",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now
  };
  const b64url = (obj) => Buffer.from(JSON.stringify(obj)).toString("base64url");
  const unsigned = `${b64url(header)}.${b64url(claim)}`;
  const signature = crypto.sign("RSA-SHA256", Buffer.from(unsigned), privateKey).toString("base64url");
  const jwt = `${unsigned}.${signature}`;
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`
  });
  if (!res.ok) throw new Error(`OAuth token fetch: ${res.status} ${await res.text()}`);
  const data = await res.json();
  _accessToken = data.access_token;
  _tokenExpiry = Date.now() + data.expires_in * 1e3;
  return _accessToken;
}
function toFirestoreValue(v) {
  if (v === null || v === void 0) return { nullValue: null };
  if (typeof v === "boolean") return { booleanValue: v };
  if (typeof v === "number") return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  if (typeof v === "string") return { stringValue: v };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(toFirestoreValue) } };
  if (typeof v === "object") {
    const fields = {};
    for (const [k, val] of Object.entries(v)) fields[k] = toFirestoreValue(val);
    return { mapValue: { fields } };
  }
  return { stringValue: String(v) };
}
function fromFirestoreValue(v) {
  if (!v) return null;
  if ("nullValue" in v) return null;
  if ("booleanValue" in v) return v.booleanValue;
  if ("integerValue" in v) return parseInt(v.integerValue);
  if ("doubleValue" in v) return v.doubleValue;
  if ("stringValue" in v) return v.stringValue;
  if ("timestampValue" in v) return v.timestampValue;
  if ("arrayValue" in v) return (v.arrayValue.values || []).map(fromFirestoreValue);
  if ("mapValue" in v) {
    const out = {};
    for (const [k, val] of Object.entries(v.mapValue.fields || {})) out[k] = fromFirestoreValue(val);
    return out;
  }
  return null;
}
function docToObj(doc) {
  if (!doc || !doc.fields) return null;
  const out = {};
  for (const [k, v] of Object.entries(doc.fields)) out[k] = fromFirestoreValue(v);
  return out;
}
function objToFields(obj) {
  const fields = {};
  for (const [k, v] of Object.entries(obj)) fields[k] = toFirestoreValue(v);
  return fields;
}
var BASE = (proj) => `https://firestore.googleapis.com/v1/projects/${proj}/databases/(default)/documents`;
function getDb() {
  return {
    async setDoc(collection, docId, data) {
      const token = await getAccessToken();
      const url = `${BASE(getProjectId())}/${collection}/${encodeURIComponent(docId)}`;
      const res = await fetch(url, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ fields: objToFields(data) })
      });
      if (!res.ok) throw new Error(`setDoc failed: ${res.status} ${await res.text()}`);
      return await res.json();
    },
    async getDoc(collection, docId) {
      const token = await getAccessToken();
      const url = `${BASE(getProjectId())}/${collection}/${encodeURIComponent(docId)}`;
      const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error(`getDoc failed: ${res.status}`);
      return docToObj(await res.json());
    },
    async listDocs(collection, { orderBy, limit } = {}) {
      const token = await getAccessToken();
      let url = `${BASE(getProjectId())}/${collection}?pageSize=${limit || 50}`;
      if (orderBy) url += `&orderBy=${orderBy.field}%20${orderBy.direction || "desc"}`;
      const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error(`listDocs failed: ${res.status}`);
      const data = await res.json();
      return (data.documents || []).map((d) => ({ id: d.name.split("/").pop(), ...docToObj(d) }));
    }
  };
}

// netlify/functions/sentinel-scan-save.js
var CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type", "Content-Type": "application/json" };
var sentinel_scan_save_default = async (req) => {
  if (req.method === "OPTIONS") return new Response("", { status: 200, headers: CORS });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST only" }), { status: 405, headers: CORS });
  try {
    const body = await req.json();
    const { scanId, startDate, endDate, results, meta } = body;
    if (!scanId || !results) return new Response(JSON.stringify({ error: "scanId and results required" }), { status: 400, headers: CORS });
    const db = getDb();
    const flagged = results.filter((r) => r.risk && r.risk !== "low" && r.risk !== "nodata");
    const totalStolen = results.reduce((a, r) => a + (r.stolenHrs || 0), 0);
    const totalCost = results.reduce((a, r) => a + (r.stolenDollars || 0), 0);
    const scanDoc = {
      scanId,
      startDate,
      endDate,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      driverCount: results.length,
      flaggedCount: flagged.length,
      critical: results.filter((r) => r.risk === "critical").length,
      high: results.filter((r) => r.risk === "high").length,
      medium: results.filter((r) => r.risk === "medium").length,
      totalStolenHrs: +totalStolen.toFixed(2),
      totalCost: +totalCost.toFixed(2),
      meta: meta || {},
      drivers: results.map((r) => ({
        name: r.name || "",
        canonicalName: r.canonicalName || r.name || "",
        risk: r.risk || "nodata",
        score: r.score || 0,
        driverType: r.driverType || "",
        driverRole: r.driverRole || "",
        truck: r.truck || "",
        clockIn: r.clockIn || "",
        clockOut: r.clockOut || "",
        totalHrs: r.totalHrs || 0,
        stolenHrs: r.stolenHrs || 0,
        stolenDollars: r.stolenDollars || 0,
        flags: (r.flags || []).map((f) => typeof f === "string" ? { title: f } : { title: f.title || "", severity: f.severity || "", detail: f.detail || "" }),
        hasData: r.hasData !== false,
        b600Matched: r.b600Matched || false
      }))
    };
    await db.setDoc("sentinelScans", scanId, scanDoc);
    for (const r of results) {
      const canonical = r.canonicalName || r.name;
      if (!canonical) continue;
      const docId = canonical.toLowerCase().replace(/[^a-z0-9]+/g, "-");
      const flagsThisScan = {};
      (r.flags || []).forEach((f) => {
        const title = typeof f === "string" ? f : f.title || "unknown";
        flagsThisScan[title] = (flagsThisScan[title] || 0) + 1;
      });
      const existing = await db.getDoc("sentinelDriverHistory", docId);
      const updated = existing ? {
        canonicalName: canonical,
        displayName: r.name,
        driverType: r.driverType || existing.driverType || "",
        driverRole: r.driverRole || existing.driverRole || "",
        totalScans: (existing.totalScans || 0) + 1,
        totalFlags: (existing.totalFlags || 0) + (r.flags || []).length,
        totalStolenHrs: +((existing.totalStolenHrs || 0) + (r.stolenHrs || 0)).toFixed(2),
        totalCost: +((existing.totalCost || 0) + (r.stolenDollars || 0)).toFixed(2),
        riskCounts: {
          critical: (existing.riskCounts?.critical || 0) + (r.risk === "critical" ? 1 : 0),
          high: (existing.riskCounts?.high || 0) + (r.risk === "high" ? 1 : 0),
          medium: (existing.riskCounts?.medium || 0) + (r.risk === "medium" ? 1 : 0),
          low: (existing.riskCounts?.low || 0) + (r.risk === "low" ? 1 : 0)
        },
        flagFrequency: (() => {
          const ff = { ...existing.flagFrequency || {} };
          for (const [k, v] of Object.entries(flagsThisScan)) ff[k] = (ff[k] || 0) + v;
          return ff;
        })(),
        firstSeen: existing.firstSeen || (/* @__PURE__ */ new Date()).toISOString(),
        lastSeen: (/* @__PURE__ */ new Date()).toISOString(),
        lastScanId: scanId
      } : {
        canonicalName: canonical,
        displayName: r.name,
        driverType: r.driverType || "",
        driverRole: r.driverRole || "",
        totalScans: 1,
        totalFlags: (r.flags || []).length,
        totalStolenHrs: +(r.stolenHrs || 0).toFixed(2),
        totalCost: +(r.stolenDollars || 0).toFixed(2),
        riskCounts: {
          critical: r.risk === "critical" ? 1 : 0,
          high: r.risk === "high" ? 1 : 0,
          medium: r.risk === "medium" ? 1 : 0,
          low: r.risk === "low" ? 1 : 0
        },
        flagFrequency: flagsThisScan,
        firstSeen: (/* @__PURE__ */ new Date()).toISOString(),
        lastSeen: (/* @__PURE__ */ new Date()).toISOString(),
        lastScanId: scanId
      };
      await db.setDoc("sentinelDriverHistory", docId, updated);
    }
    return new Response(JSON.stringify({ success: true, scanId, driverCount: results.length, flaggedCount: flagged.length }), { status: 200, headers: CORS });
  } catch (err) {
    console.error("[sentinel-scan-save]", err);
    return new Response(JSON.stringify({ error: err.message, stack: err.stack?.substring(0, 300) }), { status: 500, headers: CORS });
  }
};
var config = { path: "/api/sentinel-scan-save" };
export {
  config,
  sentinel_scan_save_default as default
};


import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/nuvizz-route-audit.js
var NUVIZZ_BASE = Netlify.env.get("NUVIZZ_BASE_URL") || "https://portal.nuvizz.com/deliverit/openapi/v7";
var COMPANY_CODE = Netlify.env.get("NUVIZZ_COMPANY_CODE") || "davis";
function authHeader() {
  const u = Netlify.env.get("NUVIZZ_USERNAME");
  const p = Netlify.env.get("NUVIZZ_PASSWORD");
  if (!u || !p) throw new Error("NUVIZZ_USERNAME / NUVIZZ_PASSWORD env vars not set");
  return "Basic " + btoa(`${u}:${p}`);
}
async function nv(path) {
  const res = await fetch(`${NUVIZZ_BASE}${path}`, {
    headers: { Authorization: authHeader(), "Content-Type": "application/json" }
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`NuVizz ${res.status} ${path}: ${txt.substring(0, 200)}`);
  }
  return res.json();
}
function diffMins(a, b) {
  if (!a || !b) return null;
  return Math.round((new Date(b) - new Date(a)) / 6e4);
}
function fmtTime(dttm) {
  if (!dttm) return null;
  return new Date(dttm).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
}
async function fetchLoadFull(loadNbr) {
  const raw = await nv(`/load/info/${encodeURIComponent(loadNbr)}/${COMPANY_CODE}`);
  const h = raw.Load?.loadHeader || {};
  const exec = raw.Load?.loadExecutionInfo || {};
  const assign = raw.Load?.loadAssignment || {};
  const stops = (raw.Load?.stops || []).map((s) => {
    const st = s.stop || {};
    const ex = s.stopExecutionInfo || {};
    const to = ex.to || {};
    return {
      stopId: st.stopId,
      stopNbr: st.stopNbr,
      stopSeq: st.stopSeq,
      stopType: st.stopType,
      stopStatus: ex.stopStatus,
      city: st.to?.address?.city,
      state: st.to?.address?.state,
      plannedEta: to.plannedEtaDTTM,
      actualArrival: to.arrivalDTTM,
      actualConfirmed: to.confirmedDTTM,
      actualDeparture: to.departureDTTM,
      dwellMins: to.duration,
      milestoNext: to.plannedDistanceToNextStop,
      minsToNext: to.plannedDurationToNextStop,
      etaCode: to.etaCode,
      weight: st.weight,
      pallets: st.totalPallets,
      exceptionPresent: ex.exceptionPresent,
      exceptions: (ex.exceptions || []).map((e) => e.exceptionDesc).filter(Boolean)
    };
  });
  return {
    loadNbr: h.loadNbr,
    loadId: h.loadId,
    routeName: h.routeName,
    driverName: assign.driverName,
    driverEmail: assign.driverEmail,
    driverUserName: assign.driverUserName,
    tractorNbr: h.tractorNbr,
    trailerNbr: h.trailerNbr,
    loadStatus: exec.loadStatus,
    plannedStartDttm: h.earliestStartDttm,
    actualStartDttm: exec.actualStartDTTM,
    actualEndDttm: exec.actualEndDTTM,
    plannedDistMiles: exec.plannedDistanceMiles,
    actualDistMiles: exec.actualDistanceMiles,
    plannedDurationMins: exec.plannedDuration,
    actualDurationMins: exec.actualDuration,
    plannedDriveTimeMins: exec.plannedDriveTime,
    actualDriveTimeMins: exec.actualDriveTime,
    stemOutMiles: h.rtOptInfo?.stemOutMiles,
    deadHeadMiles: exec.plannedDeadHeadMiles,
    stopsOnRoute: exec.stopsOnRoute,
    totalWeight: h.weight,
    totalPallets: h.totalPallets,
    totalCartons: h.totalCartons,
    stops
  };
}
function scoreRoute(load) {
  const flags = [];
  let score = 0;
  const deliveryStops = load.stops.filter((s) => s.stopType === "DO" && s.actualArrival).sort((a, b) => new Date(a.actualArrival) - new Date(b.actualArrival));
  const pickupStops = load.stops.filter((s) => s.stopType === "PU" && s.actualArrival);
  const firstDelivery = deliveryStops[0] || null;
  const lastDelivery = deliveryStops[deliveryStops.length - 1] || null;
  const routeStartDttm = load.actualStartDttm;
  const routeEndDttm = load.actualEndDttm;
  const routeSpanMins = diffMins(routeStartDttm, routeEndDttm);
  const firstDeliveryMins = diffMins(routeStartDttm, firstDelivery?.actualArrival);
  const lastDeliveryMins = diffMins(routeStartDttm, lastDelivery?.actualArrival);
  if (firstDeliveryMins != null && firstDeliveryMins > 90) {
    flags.push(`Late First Delivery \u2014 ${firstDeliveryMins}min after route start`);
    score += firstDeliveryMins > 150 ? 40 : 20;
  }
  const longDwells = load.stops.filter((s) => s.dwellMins != null && s.dwellMins > 35);
  longDwells.forEach((s) => {
    flags.push(`Stop ${s.stopNbr} \u2014 ${s.dwellMins}min dwell`);
    score += s.dwellMins > 60 ? 30 : 15;
  });
  if (load.actualDistMiles && load.plannedDistMiles) {
    const excessPct = (load.actualDistMiles - load.plannedDistMiles) / load.plannedDistMiles * 100;
    if (excessPct > 15) {
      flags.push(`Excess Mileage \u2014 ${load.actualDistMiles.toFixed(1)} actual vs ${load.plannedDistMiles.toFixed(1)} planned (${excessPct.toFixed(0)}% over)`);
      score += excessPct > 30 ? 35 : 20;
    }
  }
  if (load.actualDurationMins && load.plannedDurationMins) {
    const excessMins = load.actualDurationMins - load.plannedDurationMins;
    if (excessMins > 60) {
      flags.push(`Route Duration Overrun \u2014 ${excessMins}min over plan`);
      score += excessMins > 120 ? 30 : 15;
    }
  }
  let microCluster = 0;
  for (let i = 0; i < deliveryStops.length; i++) {
    const dwell = deliveryStops[i].dwellMins;
    if (dwell != null && dwell < 3) {
      microCluster++;
    } else {
      if (microCluster >= 3) {
        flags.push(`Micro-Stop Cluster \u2014 ${microCluster} stops <3min dwell`);
        score += 25;
      }
      microCluster = 0;
    }
  }
  if (microCluster >= 3) {
    flags.push(`Micro-Stop Cluster \u2014 ${microCluster} stops <3min dwell`);
    score += 25;
  }
  const lateStops = load.stops.filter((s) => s.etaCode === "DELAYED");
  if (lateStops.length > 3) {
    flags.push(`${lateStops.length} Late Stops (NuVizz DELAYED)`);
    score += lateStops.length * 5;
  }
  const exStops = load.stops.filter((s) => s.exceptionPresent);
  if (exStops.length > 0) {
    const excTypes = [...new Set(exStops.flatMap((s) => s.exceptions))].slice(0, 3).join(", ");
    flags.push(`${exStops.length} Stop Exception(s): ${excTypes || "See detail"}`);
    score += exStops.length * 10;
  }
  if (lastDelivery && routeEndDttm) {
    const lastToEnd = diffMins(lastDelivery.actualArrival, routeEndDttm);
    if (lastToEnd != null && lastToEnd > 120) {
      flags.push(`${lastToEnd}min gap \u2014 Last Delivery to Route End`);
      score += lastToEnd > 180 ? 30 : 15;
    }
  }
  const engineHours = load.actualDurationMins != null ? load.actualDurationMins / 60 : null;
  const driveHours = load.actualDriveTimeMins != null ? load.actualDriveTimeMins / 60 : null;
  const totalShiftMins = routeSpanMins;
  const accountedMins = (load.actualDriveTimeMins || 0) + load.stops.filter((s) => s.dwellMins).reduce((a, s) => a + s.dwellMins, 0);
  const unaccountedMins = totalShiftMins != null ? Math.max(0, totalShiftMins - accountedMins) : null;
  const stolenHours = unaccountedMins != null ? unaccountedMins / 60 : null;
  const stolenDollars = stolenHours != null ? stolenHours * 23 : null;
  const risk = score >= 150 ? "critical" : score >= 80 ? "high" : score >= 40 ? "medium" : "low";
  const mph = load.actualDistMiles && engineHours && engineHours > 0 ? (load.actualDistMiles / engineHours).toFixed(1) : null;
  return {
    // ── SENTINEL display fields ──
    driver: load.driverName || load.driverUserName || "Unknown",
    truck: load.tractorNbr || load.trailerNbr || "\u2014",
    loadNbr: load.loadNbr,
    routeName: load.routeName,
    // Clock times (from route actual start/end)
    clockIn: fmtTime(load.actualStartDttm),
    clockOut: fmtTime(load.actualEndDttm),
    // Engine / drive
    engineH: engineHours != null ? parseFloat(engineHours.toFixed(2)) : null,
    driveH: driveHours != null ? parseFloat(driveHours.toFixed(2)) : null,
    // Mileage
    miles: load.actualDistMiles != null ? parseFloat(load.actualDistMiles.toFixed(1)) : null,
    plannedMiles: load.plannedDistMiles != null ? parseFloat(load.plannedDistMiles.toFixed(1)) : null,
    stemOutMiles: load.stemOutMiles != null ? parseFloat(load.stemOutMiles.toFixed(1)) : null,
    mph: mph != null ? parseFloat(mph) : null,
    stops: deliveryStops.length,
    totalStops: load.stops.length,
    // ── SENTINEL audit scores ──
    score,
    risk,
    flags: flags.join("|"),
    flagList: flags,
    flagCount: flags.length,
    // ── Time theft estimates ──
    stolenH: stolenHours != null ? parseFloat(stolenHours.toFixed(2)) : null,
    stolenD: stolenDollars != null ? parseFloat(stolenDollars.toFixed(2)) : null,
    // ── First / Last delivery (key new data) ──
    firstDeliveryTime: fmtTime(firstDelivery?.actualArrival),
    firstDeliveryDttm: firstDelivery?.actualArrival || null,
    firstDeliveryCity: firstDelivery ? `${firstDelivery.city}, ${firstDelivery.state}` : null,
    firstDeliveryMinsAfterStart: firstDeliveryMins,
    lastDeliveryTime: fmtTime(lastDelivery?.actualArrival),
    lastDeliveryDttm: lastDelivery?.actualArrival || null,
    lastDeliveryCity: lastDelivery ? `${lastDelivery.city}, ${lastDelivery.state}` : null,
    routeSpanMins,
    routeSpanHrs: routeSpanMins != null ? parseFloat((routeSpanMins / 60).toFixed(2)) : null,
    unaccountedMins,
    // Source tag
    source: "NuVizz Live API",
    // ── Full stop detail for drill-down ──
    stopDetail: deliveryStops.map((s) => ({
      seq: s.stopSeq,
      stopNbr: s.stopNbr,
      city: `${s.city}, ${s.state}`,
      plannedEta: fmtTime(s.plannedEta),
      actualArrival: fmtTime(s.actualArrival),
      actualDeparture: fmtTime(s.actualDeparture),
      dwellMins: s.dwellMins,
      etaCode: s.etaCode,
      milestoNext: s.milestoNext,
      exceptionPresent: s.exceptionPresent,
      exceptions: s.exceptions
    }))
  };
}
var nuvizz_route_audit_default = async (req) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (req.method === "OPTIONS") {
    return new Response("", { status: 200, headers: cors });
  }
  if (req.method !== "GET") {
    return new Response(JSON.stringify({ error: "GET only" }), { status: 405, headers: cors });
  }
  const url = new URL(req.url);
  const loadNbr = url.searchParams.get("loadNbr");
  if (!loadNbr) {
    return new Response(
      JSON.stringify({ error: "loadNbr param required. Example: ?loadNbr=DAVIS-2024-001" }),
      { status: 400, headers: cors }
    );
  }
  try {
    const load = await fetchLoadFull(loadNbr);
    const auditRecord = scoreRoute(load);
    return new Response(
      JSON.stringify({ success: true, auditRecord, load }),
      { status: 200, headers: cors }
    );
  } catch (err) {
    console.error("[nuvizz-route-audit]", err.message);
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: cors }
    );
  }
};
var config = {
  path: "/api/nuvizz-route-audit"
};
export {
  config,
  nuvizz_route_audit_default as default
};
